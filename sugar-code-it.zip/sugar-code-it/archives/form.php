
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $grade = htmlspecialchars($_POST['grade']);
    $level = htmlspecialchars($_POST['level']);
    $interests = htmlspecialchars($_POST['interests']);

    // Your email
    $to = "latifmohid@outlook.com";

    // Subject
    $subject = "New Contact Form Submission";

    // Email content
    $body = "Name: $name\n";
    $body .= "Email: $email\n\n";
    $body .= "Grade:\n$message";
    $body .= "Reason to contact:\n$level";
    $body .= "Message:\n$interests";

    // Headers
    $headers = "From: $email";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo "Email sent successfully!";
        echo "Please wait...";
        sleep(3);

    } else {
        echo "Failed to send email.";
        echo "Please wait...";
        sleep(3);
    }
    
    header("Location:index.html");
    exit();

}
?>
