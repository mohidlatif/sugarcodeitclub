const menu = document.querySelector('.menu');
const links = document.querySelector('.links');

if (menu && links) {
  menu.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
  });
}

const currentPage = location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.links a').forEach((link) => {
  if (link.getAttribute('href') === currentPage) link.classList.add('active');
});
